const express = require('express');
const router = express.Router();
const { pool } = require('../utils/db');

// Only POST
router.post('/', async (req, res) => {
  const { CompanyName, FirstName, LastName } = req.body;

  if (!CompanyName || !FirstName || !LastName) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  try {
    await pool.execute(
      'INSERT INTO clientAdmin (CompanyName, FirstName, LastName) VALUES (?, ?, ?)',
      [CompanyName, FirstName, LastName]
    );
    res.status(201).json({ message: 'Admin created successfully.' });
  } catch (err) {
    console.error('❌ Create error:', err);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

module.exports = router;
