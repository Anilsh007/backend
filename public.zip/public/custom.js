$(document).ready(function () {
    $('.nav-item').on('click', function () {
        var pageName = $(this).attr('page-name');
        $('#content').load(pageName + '.html');
    });
});